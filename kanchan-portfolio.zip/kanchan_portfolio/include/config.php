<?php
$connect=mysqli_connect("localhost","kanchan_cv","{g4!g(zN(H0-","kanchan_cv");