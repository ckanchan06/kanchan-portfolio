<?php
// include_once('config.php');
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     // Collect form inputs
//     $name = mysqli_real_escape_string($connect, $_POST['name']);
//     $email = mysqli_real_escape_string($connect, $_POST['email']);
//     $mob = mysqli_real_escape_string($connect, $_POST['mob']);
//     $filename = $_FILES['image']['name'];
//     $file_tmp = $_FILES['image']['tmp_name'];

//     // Prepare email details
//     $to = 'kanchanc7038@gmail.com';
//     $subject = 'User Messages & Queries';
//     $message = "
//     Username: $name\n
//     Phone: $mob\n
//     Email: $email\n
//     Uploaded File: $filename\n";
//     $headers = "From: $email\r\n";

//     // Handle file upload
//     if (!empty($filename)) {
//         $upload_dir = 'uploads/';
//         $file_path = $upload_dir . basename($filename);

//         // Check file type
//         $file_type = mime_content_type($file_tmp);
//         $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

//         if (in_array($file_type, $allowed_types)) {
//             if (move_uploaded_file($file_tmp, $file_path)) {
//               // echo "File uploaded successfully.<br>";
//             } 
//         } else {
//             echo "Invalid file type. Only JPG, PNG, and GIF files are allowed.<br>";
//             exit;
//         }
//     }

//     // Insert data into the database
//     $query = "INSERT INTO contact (cname, cemail, mob, img) VALUES ('$name', '$email', '$mob', '$filename')";
//     $run = mysqli_query($connect, $query);

//     if (!$run) {
//         echo "Database insertion failed: " . mysqli_error($connect) . "<br>";
//         exit;
//     }

//     // Send email
//     if (mail($to, $subject, $message, $headers)) {
//         echo "<script>";
//         echo "alert('Your message has been sent. Thank you!');";
//         echo "window.location.href='../index';";
//         echo "</script>";
//     } else {
//         echo "Mail sending failed. Please check your mail server configuration.<br>";
//     }
// }



//mime use
include_once('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form inputs
    $name = mysqli_real_escape_string($connect, $_POST['name']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $mob = mysqli_real_escape_string($connect, $_POST['mob']);
    $filename = $_FILES['image']['name'];
    $file_tmp = $_FILES['image']['tmp_name'];

    // Handle file upload
    $file_content = '';
    $upload_dir = 'uploads/';
    $file_path = '';
    if (!empty($filename)) {
        $file_path = $upload_dir . basename($filename);
        $file_type = mime_content_type($file_tmp);
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($file_tmp, $file_path)) {
                $file_content = chunk_split(base64_encode(file_get_contents($file_path))); // Encode file content
            } else {
                echo "File upload failed.";
                exit;
            }
        } else {
            echo "Invalid file type. Only JPG, PNG, and GIF files are allowed.";
            exit;
        }
    }

    // Prepare email details
    $to = 'kanchanc7038@gmail.com';
    $subject = 'User Messages & Queries';
    $message = "
    Username: $name\n
    Phone: $mob\n
    Email: $email\n";
    
    // Boundary
    $boundary = md5(time());

    // Email headers
    $headers = "From: $email\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    // Email body
    $email_body = "--$boundary\r\n";
    $email_body .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $email_body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $email_body .= $message . "\r\n";

    // Attach the file
    if (!empty($file_content)) {
        $email_body .= "--$boundary\r\n";
        $email_body .= "Content-Type: $file_type; name=\"$filename\"\r\n";
        $email_body .= "Content-Transfer-Encoding: base64\r\n";
        $email_body .= "Content-Disposition: attachment; filename=\"$filename\"\r\n\r\n";
        $email_body .= $file_content . "\r\n";
    }

    // Closing boundary
    $email_body .= "--$boundary--";

    // Send email
    if (mail($to, $subject, $email_body, $headers)) {
        echo "<script>";
        echo "alert('Your message with the attachment has been sent. Thank you!');";
        echo "window.location.href='../index';";
        echo "</script>";
    } else {
        echo "Mail sending failed. Please check your mail server configuration.<br>";
    }

    // Insert data into the database
    $query = "INSERT INTO contact (cname, cemail, mob, img) VALUES ('$name', '$email', '$mob', '$filename')";
    $run = mysqli_query($connect, $query);

    if (!$run) {
        echo "Database insertion failed: " . mysqli_error($connect) . "<br>";
        exit;
    }
}
?>
