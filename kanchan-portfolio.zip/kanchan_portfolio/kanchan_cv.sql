-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2024 at 03:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanchan_cv`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus_setup`
--

CREATE TABLE `aboutus_setup` (
  `id` int(11) NOT NULL,
  `shortdesc` text NOT NULL,
  `heading` text NOT NULL,
  `subheading` text NOT NULL,
  `longdesc` text NOT NULL,
  `website` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aboutus_setup`
--

INSERT INTO `aboutus_setup` (`id`, `shortdesc`, `heading`, `subheading`, `longdesc`, `website`, `dob`) VALUES
(1, 'I have two+ years of hands-on experience in\r\nPHP development, demonstrating a strong\r\nproficiency in creating dynamic and responsive\r\nweb applications. My skill set includes\r\nproficient use of PHP, database integration,\r\nand version control systems. Through these\r\ntwo years, I\'ve successfully contributed to\r\nvarious projects, honing my problem-solving\r\nabilities and fostering a deep understanding of\r\nweb development principles. My dedication to\r\nclean and efficient coding, coupled with a\r\npassion for staying updated with industry\r\ntrends, empowers me to deliver effective\r\nsolutions and contribute positively to any\r\ndevelopment team.', 'PHP Developer', 'Currently Working As Freelancer', '', 'https://chaudharikanchan.github.io/', '06 SEPTEMBER, 1996');

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `user_id` varchar(250) NOT NULL,
  `user_pass` varchar(250) NOT NULL,
  `user_access` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `user_id`, `user_pass`, `user_access`) VALUES
(1, 'Kanchan Chaudhari', 'kanchanc@gmail.com', 'K@nch@n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `basic_setup`
--

CREATE TABLE `basic_setup` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `keyword` text NOT NULL,
  `icon` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `basic_setup`
--

INSERT INTO `basic_setup` (`id`, `title`, `description`, `keyword`, `icon`) VALUES
(1, 'Kanchan Chaudhari', 'I am a PHP Developer, I make website and php web portals .', 'PHP Development', 'favicon.png');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `cemail` varchar(250) NOT NULL,
  `mob` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_setup`
--

CREATE TABLE `personal_setup` (
  `id` int(11) NOT NULL,
  `profilepic` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `twitter` varchar(200) NOT NULL,
  `linkedin` varchar(200) NOT NULL,
  `homewallpaper` varchar(200) NOT NULL,
  `professions` varchar(200) NOT NULL,
  `location` text NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `emailid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_setup`
--

INSERT INTO `personal_setup` (`id`, `profilepic`, `name`, `twitter`, `linkedin`, `homewallpaper`, `professions`, `location`, `mobile`, `emailid`) VALUES
(1, 'kanchan (3).png', 'Kanchan Chaudhari', '7038624965', 'https://in.linkedin.com/in/kanchan-chaudhari-b883b2235', '8e46150f790fbefe438d9c2767c32ad1.gif', 'PHP Developer, Web Developer', 'Sai Bhagya Society,Deepali Nagar, Mumbai Naka Nashik - 422009', '+918329684365', 'kanchanc7038@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `projectname` varchar(250) NOT NULL,
  `projectpic` varchar(250) NOT NULL,
  `projectlink` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `projectname`, `projectpic`, `projectlink`) VALUES
(1, 'Webzons', 'webzons.png', 'https://webzons.in/'),
(2, 'Stylequest', 'stylequest.png', 'https://www.stylequest.in/'),
(3, 'Perfect Protection Security Services', 'ppssweb.png', 'https://perfectprotection.co.in/'),
(4, 'Admin Panel Perfect Protection Security Services', 'ppssadmin.png', 'https://perfectprotection.co.in/admin/'),
(5, 'Vision Wellness Zone', 'wellnessweb.png', 'http://prabhakarnikam.com/'),
(6, 'Admin Panel Vision Wellness Zone ', 'visionadmin.png', 'http://prabhakarnikam.com/admin/'),
(7, 'Swatik Packaging Industry', 'swatikweb.png', 'https://perfectprotection.co.in/swastik/'),
(8, 'Admin Panel Swatik Packaging Industry', 'swatikadmin.png', 'https://perfectprotection.co.in/swastik/admin/login?redirect=/swastik/admin/index'),
(9, 'Megarelief Pain Managment Clinic', 'painclinicweb.png', 'https://painclinicnashik.com/'),
(10, 'Admin Panel Megarelief Pain Managment Clinic', 'painclinicadmin.png', 'https://painclinicnashik.com/admin/login?redirect=/admin/.php'),
(11, 'Adityhightech Nursery', 'adityahightechAdmin.png', 'http://adityhightechnursery.in/login?redirect=/'),
(12, 'Swiggy Web Portal', 'swiggyadmin.png', 'https://perfectprotection.co.in/swiggy/'),
(13, 'Wow Organization', 'wow.png', 'https://woworganization.com/');

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `year` varchar(250) NOT NULL,
  `ogname` varchar(250) NOT NULL,
  `workdesc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`id`, `category`, `title`, `year`, `ogname`, `workdesc`) VALUES
(1, 'e', 'Class 11th - 12th', '2013-2015', 'DDSP COLLEGE ERANDOL', ''),
(2, 'e', 'Bachelor of Computer Engineer', '2015-2019', 'GF\'s GCOE JALGAON', ''),
(3, 'e', 'Web Developer (Intern)', 'SEP 2019 - MAR 2020', 'Sumago Infotech Pvt Ltd', ''),
(4, 'pe', 'PHP Developer', 'Mar 2020 - June 2020', 'Ganulf Services.Pvt.Ltd.', ''),
(5, 'pe', 'WordPress Developer ', 'Oct 2020 – Mar 2021', 'RP WEB', ''),
(6, 'pe', 'PHP Developer', 'Oct 2021 – Nov 2023', 'Paarsh Infotech Pvt Ltd', ''),
(7, 'pe', 'Software Programmer', 'Dec 2023 - Apr- 2024', 'Sparklers Infotech Pvt Ltd', '');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(11) NOT NULL,
  `skill` varchar(250) NOT NULL,
  `score` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill`, `score`) VALUES
(1, 'HTML ', '90'),
(2, 'CSS', '85'),
(3, 'BOOTSTRAP', '95'),
(4, 'JAVASCRIPT', '60'),
(5, 'JQUERY', '60'),
(6, 'PHP', '75'),
(7, 'MYSQL', '85');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL,
  `userq` varchar(250) NOT NULL,
  `userv` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`id`, `userq`, `userv`) VALUES
(1, 'Birthday', '06 September,1996'),
(2, 'Age', '28'),
(3, 'Website', 'https://chaudharikanchan.github.io/'),
(4, 'Degree', 'Bachelor of Computer Engineer\n'),
(5, 'Mobile', '+918329684365'),
(6, 'Email', 'kanchanc7038@gmail.com'),
(7, 'City', 'Nashik');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus_setup`
--
ALTER TABLE `aboutus_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basic_setup`
--
ALTER TABLE `basic_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_setup`
--
ALTER TABLE `personal_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus_setup`
--
ALTER TABLE `aboutus_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `basic_setup`
--
ALTER TABLE `basic_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_setup`
--
ALTER TABLE `personal_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
