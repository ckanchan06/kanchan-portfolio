<h2>Edit Home Section</h2>
<?php
   if(isset($_GET['msg'])){
       
   if($_GET['msg']=='updated'){
   ?>
<div class="alert alert-success text-center" role="alert">
   Successfully Updated !
</div>
<?php
   }  
   if($_GET['msg']=='error'){
       ?>
<div class="alert alert-danger text-center" role="alert">
   something wrong with your image please check type or size !
</div>
<?php
   } } 
   ?>  
<form method="post" action="php/uhome.php" enctype="multipart/form-data">
   <div class="row">
      <div class="col-12 col-md-6">
          <img src="../assets/img/<?=$data['profilepic']?>" class="oo img-thumbnail" width="100" height="100"><br>
         <label>Profile Pic (Minimum 600px X 600px, Maxsize 2mb)</label>
         <div class="custom-file">
            <input type="file" name="profile" class="custom-file-input" id="profilepic">
            <label class="custom-file-label" for="profilepic">Choose Profile Pic...</label>
         </div>   
      </div> 
      <div class="col-12 col-md-6">
         <img src="../assets/img/<?=$data['homewallpaper']?>" class="oo img-thumbnail" width="150" height="250"><br>
         <label>Home Cover (Minimum 1920 X 1280, Maxsize 2mb)</label>
         <div class="custom-file">
            <input type="file" name="cover" class="custom-file-input" id="profilepic">
            <label class="custom-file-label" for="profilepic">Choose Home Cover...</label>
         </div>
      </div>
   </div>
   <div class="form-row">
      <div class="form-group col-md-6">
         <label for="name">Name</label>
         <input type="name" name="name" value="<?=$data['name']?>" class="form-control" id="name" placeholder="Mohan Goswami">
      </div>
      <div class="form-group col-md-6">
         <label for="email">Email</label>
         <input type="email" name="email" value="<?=$data['emailid']?>" class="form-control" id="email" placeholder="workwithmohan@gmail.com">
      </div>
      <div class="form-group col-md-4">
         <label for="twitter">What's Up </label>
         <input type="tel" class="form-control" value="<?=$data['twitter']?>" name="twitter" id="twitter" placeholder="7038624965">
      </div>
      <div class="form-group col-md-4">
         <label for="mobile">Mobile No</label>
         <input type="text" class="form-control" value="<?=$data['mobile']?>" name="mobile" id="mobile" placeholder="+918329684365">
      </div>
      <div class="form-group col-md-4">
         <label for="linkedin">Linkedin</label>
         <input type="text" class="form-control" value="<?=$data['linkedin']?>" name="linkedin" id="linkedin" placeholder="">
      </div>
      <div class="col-md-6">
         <div class="form-group">
            <label for="address">Address</label>
            <textarea name="address" class="form-control" id="address"><?=$data['location']?></textarea>
         </div>
      </div>
      <div class="col-md-6">
         <div class="form-group">
            <label for="profession">Proffesion Titles (Separate with ',' comma)</label>
            <input type="text" class="form-control" name="profession" value="<?=$data['professions']?>" id="profession" placeholder="Web Developer,PHP Developer">
         </div>
      </div>
      <div class="col-12">
         <input type="submit" name="save" class="btn btn-dark" value="Save Changes">
      </div>
   </div>
   </div>
</form>