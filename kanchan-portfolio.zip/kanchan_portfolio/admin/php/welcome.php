   <h2>User Messages & Querys</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>File Uploaded</th>
            </tr>
          </thead>
          <tbody>
            
             <?php
    
      $queryrun=mysqli_query($connect,"SELECT * FROM contact");
      $count=0;
      while($data=mysqli_fetch_array($queryrun)){
          ?>
          <tr>
          <td>#<?=$count+1?></td>
              <td><?=$data['cname']?></td>
              <td><?=$data['cemail']?></td>
              <td><?=$data['mob']?></td>
              <td><a href="../include/uploads/<?=$data['img']?>" target="_blank"><img src="../include/uploads/<?=$data['img']?>" width="50" heigth="50"></a></td>
            </tr>
          <?php
              $count++;
      }
      if($count==0){ ?>
          <td colspan="5" align="center"> Currenty There Is No Messages or Queries !</td>
      <?php }
        ?>
              
          </tbody>
        </table>
      </div>