<?php
include_once('../../include/config.php');
if(isset($_POST['supdate'])){
    $id=$_POST['id'];
    $skill=mysqli_real_escape_string($connect,$_POST['skill']);
    $score=mysqli_real_escape_string($connect,$_POST['score']);
    $run=mysqli_query($connect,"UPDATE skills SET skill='$skill',score='$score' WHERE id='$id'");
    if($run){
        header("location:../?editabout=true#skillsection");
    }
}

if(isset($_POST['addskill'])){
    $id=$_POST['id'];
    $skill=mysqli_real_escape_string($connect,$_POST['skill']);
    $score=mysqli_real_escape_string($connect,$_POST['score']);
    $run=mysqli_query($connect,"INSERT INTO skills (skill,score) VALUES ('$skill','$score')");
    if($run){
        header("location:../?editabout=true#skillsection");
    }
}

if(isset($_GET['del'])){
    $id=$_GET['del'];
    $run=mysqli_query($connect,"DELETE FROM skills WHERE id='$id'");
    if($run){
        header("location:../?editabout=true#skillsection");
    }
}